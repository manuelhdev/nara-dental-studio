export const siteConfig = {
  name: "NARA Dental Studio",
  shortName: "NARA",
  descriptor: "Odontología · Estética · Precisión",
  city: "Los Mochis, Sinaloa",
  whatsapp: "526681234567",
  phone: "+52 668 123 4567",
  instagram: "nara.dental",
  email: "hola@naradental.mx",
  address: "Blvd. Rosales 1240, Centro, Los Mochis, Sin.",
  schedule: [
    { days: "Lunes — Viernes", hours: "9:00 — 19:00" },
    { days: "Sábado", hours: "9:00 — 14:00" },
    { days: "Domingo", hours: "Cerrado" },
  ],
}
